
public class NumberTooLarge extends Exception{

	public NumberTooLarge(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public NumberTooLarge(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public NumberTooLarge(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public NumberTooLarge(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public NumberTooLarge() {
		super();
		// TODO Auto-generated constructor stub
	}

}
