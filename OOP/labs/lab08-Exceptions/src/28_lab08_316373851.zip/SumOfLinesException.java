
public class SumOfLinesException extends Exception{
	public SumOfLinesException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public SumOfLinesException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public SumOfLinesException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public SumOfLinesException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public SumOfLinesException() {
		super();
		// TODO Auto-generated constructor stub
	}
}
