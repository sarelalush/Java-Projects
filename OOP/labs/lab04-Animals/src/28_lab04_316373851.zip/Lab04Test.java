
public class Lab04Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dog d = new Dog();
		Cat c = new Cat();
		Leopard l = new Leopard();
		c.climb();
		d.bark();
		l.climb();
	}

}
