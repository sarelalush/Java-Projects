public abstract class Shape2D {

	public abstract double area();
	
}
