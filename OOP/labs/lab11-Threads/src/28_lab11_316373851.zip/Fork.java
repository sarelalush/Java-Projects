public class Fork {
	private int owner;
	
	public Fork() {
		this.owner = 0;
	}

	public Fork(int owner) {
		this.owner = owner;
	}

	public int getOwner() {
		return owner;
	}

	public void setOwner(int owner) {
		this.owner = owner;
	}
	
}
