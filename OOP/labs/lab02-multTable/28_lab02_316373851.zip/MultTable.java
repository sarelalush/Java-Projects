
public class MultTable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Table tb = new Table(50,50);
		tb.display( 20, 30, 15, 35 );
	}

}
