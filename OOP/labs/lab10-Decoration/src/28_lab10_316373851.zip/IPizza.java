import java.util.List;

public interface IPizza {
	public int getSize() ;
	public List<String> toppings() ;
	public double howMuch() ;
}
